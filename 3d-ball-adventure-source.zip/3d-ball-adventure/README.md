# 3D Ball Adventure

A mobile-first 3D rolling-ball adventure starter built with Three.js, Vite and Capacitor.

## Features in this starter
- Real-time 3D scene and rolling ball
- Touch joystick and jump button
- Third-person follow camera
- Coins and a gem
- Moving obstacles
- 10 level progression
- Pause, restart and completion screens
- Local progress score
- GitHub Actions workflow to build a debug Android APK

## Build in GitHub Actions
1. Create a GitHub repository and upload this project.
2. Make sure `.github/workflows/android-apk.yml` is included.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and tap **Run workflow** (or push to `main`).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the `ball-adventure-debug-apk` artifact.
7. Extract the downloaded artifact ZIP; install `app-debug.apk` on your Android phone.

## Local web preview (requires Node.js)
```bash
npm install
npm run dev
```

## Important
- This is an initial playable starter, not a finished commercial game.
- The Android workflow creates a **debug APK** for testing. A Play Store release needs a signed release AAB/APK and a protected upload keystore.
- The app ID in `capacitor.config.json` is a placeholder. Change `com.example.balladventure` to a unique reverse-domain ID before publishing.
- The current level layouts are generated procedurally from simple geometry. Replace/add art assets and improve collision/level design as development continues.
