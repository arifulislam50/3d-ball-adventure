import * as THREE from 'three';
import './style.css';

const app = document.querySelector('#app');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x83d5ff);
scene.fog = new THREE.Fog(0x83d5ff, 24, 75);
const camera = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.1, 150);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'low-power' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
app.prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdaf5ff, 0x52734a, 2.0));
const sun = new THREE.DirectionalLight(0xffffff, 2.1);
sun.position.set(-8, 16, 10); sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024); scene.add(sun);

const mat = (color, roughness=0.8, metalness=0) => new THREE.MeshStandardMaterial({color, roughness, metalness});
const materials = {
  grass: mat(0x63c66b), path: mat(0x9ad9f4), edge: mat(0x3986b2),
  ball: mat(0xffb52e,0.35), coin: mat(0xffdf35,0.35,0.25),
  gem: mat(0x35e6df,0.25,0.2), obstacle: mat(0xff6b6b), finish: mat(0x8d65ff)
};
const ground = new THREE.Group(); scene.add(ground);
const ball = new THREE.Mesh(new THREE.SphereGeometry(0.55, 24, 18), materials.ball);
ball.castShadow = true; scene.add(ball);
const ballRing = new THREE.Mesh(new THREE.TorusGeometry(0.57,0.055,8,32), mat(0xffffff,0.3));
ball.add(ballRing); ballRing.rotation.x = Math.PI/2;

let level=1, score=Number(localStorage.getItem('ba-score')||0), playing=false, paused=false, complete=false;
let velocity=new THREE.Vector3(), target=new THREE.Vector2(), jumpVelocity=0, onGround=true;
let collectibles=[], obstacles=[], platforms=[], finishGate=null, checkpoint=new THREE.Vector3(0,1,4);
const $ = id => document.getElementById(id);
$('score').textContent=score;

function clearWorld(){
  while(ground.children.length){const o=ground.children.pop(); o.parent?.remove(o);}
  for(const o of [...collectibles,...obstacles,...platforms]){scene.remove(o); if(o.geometry)o.geometry.dispose();}
  collectibles=[]; obstacles=[]; platforms=[]; if(finishGate){scene.remove(finishGate);finishGate=null;}
}
function addPlatform(x,z,w,d,color=0x63c66b,y=0){
  const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,0.7,d),mat(color));
  mesh.position.set(x,y-0.35,z); mesh.receiveShadow=true; mesh.castShadow=true; scene.add(mesh); platforms.push(mesh); return mesh;
}
function addCoin(x,z,gem=false){
  const mesh=new THREE.Mesh(gem?new THREE.OctahedronGeometry(.38):new THREE.TorusGeometry(.3,.1,10,22),gem?materials.gem:materials.coin);
  mesh.position.set(x,1.1,z); mesh.rotation.x=gem?0:Math.PI/2; mesh.castShadow=true; scene.add(mesh); collectibles.push(mesh);
}
function addTree(x,z){
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.18,.24,1.3,7),mat(0x8b5737)); trunk.position.set(x,.65,z); trunk.castShadow=true; scene.add(trunk); ground.add(trunk);
  const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(.85,1),mat([0x42b96a,0x56c96c,0x75d66d][Math.floor(Math.random()*3)])); crown.position.set(x,1.8,z); crown.castShadow=true; scene.add(crown); ground.add(crown);
}
function buildLevel(n){
  clearWorld();
  const length=30+n*2;
  // Main safe rolling path with broad platforms and side islands.
  addPlatform(0,0,7,12);
  addPlatform(0,-9,5,9,0x76d48b);
  addPlatform(0,-18,6,10,0x76d48b);
  addPlatform(0,-27,7,10,0x76d48b);
  addPlatform(0,-length,8,8,0x76d48b);
  for(let z=2;z>-length;z-=5){addTree(-3.8,z);addTree(3.8,z-1);}
  // Bridges between islands
  for(let z=-5;z>-length;z-=9) addPlatform(0,z,2.6,4,0x53b5e8,.05);
  // Collectibles placed along path
  for(let z=-2;z>-length+3;z-=2.6) addCoin((Math.sin(z*0.7)*1.15),z);
  addCoin(0,-length+2,true);
  // Moving red bumpers on later levels
  for(let i=0;i<Math.min(2+n,7);i++){
    const o=new THREE.Mesh(new THREE.BoxGeometry(1.1,.65,.9),materials.obstacle);
    o.position.set(i%2?1.3:-1.3,.75,-7-i*4.2); o.castShadow=true; scene.add(o); obstacles.push(o);
  }
  // Finish arch
  finishGate=new THREE.Group();
  const postMat=mat(0x7b50db);
  for(const x of [-1.25,1.25]){const p=new THREE.Mesh(new THREE.CylinderGeometry(.13,.13,2.7,10),postMat);p.position.set(x,1.35,-length+1);finishGate.add(p);}
  const top=new THREE.Mesh(new THREE.BoxGeometry(2.7,.25,.3),mat(0xffe35b));top.position.set(0,2.65,-length+1);finishGate.add(top);
  scene.add(finishGate);
  ball.position.set(0,1,4); velocity.set(0,0,0); jumpVelocity=0; checkpoint.set(0,1,4);
  $('level').textContent=n;
}
function showMessage(text){$('message').textContent=text;$('message').classList.remove('hidden');setTimeout(()=>$('message').classList.add('hidden'),1500);}
function start(){level=Math.min(level,10); buildLevel(level); playing=true;paused=false;complete=false; $('menu').classList.add('hidden');$('pausePanel').classList.add('hidden');$('completePanel').classList.add('hidden');$('hud').classList.remove('hidden');$('controls').classList.remove('hidden');}
function finish(){if(complete)return;complete=true;playing=false;score+=10;localStorage.setItem('ba-score',score);$('score').textContent=score;$('completeText').textContent=`You collected stars and finished level ${level}!`;$('nextBtn').textContent=level>=10?'PLAY AGAIN':'NEXT LEVEL';$('completePanel').classList.remove('hidden');$('controls').classList.add('hidden');}
$('playBtn').onclick=()=>{level=1;start();};
$('pauseBtn').onclick=()=>{if(!playing)return;paused=true;playing=false;$('pausePanel').classList.remove('hidden');$('controls').classList.add('hidden');};
$('resumeBtn').onclick=()=>{paused=false;playing=true;$('pausePanel').classList.add('hidden');$('controls').classList.remove('hidden');};
$('restartBtn').onclick=()=>start();
$('homeBtn').onclick=()=>{playing=false;paused=false;$('pausePanel').classList.add('hidden');$('hud').classList.add('hidden');$('menu').classList.remove('hidden');};
$('menuBtn').onclick=()=>{$('completePanel').classList.add('hidden');$('hud').classList.add('hidden');$('menu').classList.remove('hidden');};
$('nextBtn').onclick=()=>{level=level>=10?1:level+1;start();};

// Touch joystick: normalized -1..1
const joy=$('joystick'), stick=$('stick'); let joyPointer=null;
function joyMove(e){const r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=35,l=Math.hypot(dx,dy)||1;if(l>max){dx=dx/l*max;dy=dy/l*max;}target.set(dx/max,-dy/max);stick.style.transform=`translate(${dx}px,${dy}px)`;}
joy.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joy.setPointerCapture(joyPointer);joyMove(e);});
joy.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)joyMove(e);});
function joyEnd(){joyPointer=null;target.set(0,0);stick.style.transform='translate(0,0)';}
joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
$('jumpBtn').addEventListener('pointerdown',e=>{e.preventDefault();if(playing&&onGround){jumpVelocity=7.2;onGround=false;}});
addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='a')target.x=-1;if(e.key==='ArrowRight'||e.key==='d')target.x=1;if(e.key==='ArrowUp'||e.key==='w')target.y=1;if(e.key==='ArrowDown'||e.key==='s')target.y=-1;if(e.code==='Space'&&playing&&onGround){jumpVelocity=7.2;onGround=false;}});
addEventListener('keyup',e=>{if(['ArrowLeft','ArrowRight','a','d'].includes(e.key))target.x=0;if(['ArrowUp','ArrowDown','w','s'].includes(e.key))target.y=0;});

const clock=new THREE.Clock();
function update(dt){
  if(playing){
    const forward=new THREE.Vector3(0,0,-1), right=new THREE.Vector3(1,0,0);
    const desired=right.multiplyScalar(target.x).add(forward.multiplyScalar(target.y)).normalize();
    velocity.x=THREE.MathUtils.damp(velocity.x,desired.x*7,5,dt);
    velocity.z=THREE.MathUtils.damp(velocity.z,desired.z*7,5,dt);
    ball.position.x+=velocity.x*dt; ball.position.z+=velocity.z*dt;
    jumpVelocity-=18*dt; ball.position.y+=jumpVelocity*dt;
    if(ball.position.y<=1){ball.position.y=1;jumpVelocity=0;onGround=true;}
    ball.rotation.z-=velocity.x*dt/0.55;ball.rotation.x+=velocity.z*dt/0.55;
    // Keep the ball within the broad route.
    ball.position.x=THREE.MathUtils.clamp(ball.position.x,-2.5,2.5);
    // Collectibles
    for(const c of collectibles){if(c.visible){c.rotation.y+=dt*2.2;c.position.y=1.1+Math.sin(clock.elapsedTime*3+c.position.z)*.12;if(ball.position.distanceTo(c.position)<.95){c.visible=false;score++;$('score').textContent=score;localStorage.setItem('ba-score',score);}}}
    obstacles.forEach((o,i)=>{o.position.x=(i%2?1:-1)*Math.sin(clock.elapsedTime*1.5+i)*1.6;if(ball.position.distanceTo(o.position)<.95&&ball.position.y<1.65){ball.position.copy(checkpoint);velocity.set(0,0,0);showMessage('Try again!');}});
    // Simple platform gap/fall detection; respawn at checkpoint.
    if(ball.position.y<-.5){ball.position.copy(checkpoint);velocity.set(0,0,0);jumpVelocity=0;showMessage('Back to checkpoint!');}
    if(ball.position.z < -30-level*2+3)finish();
    if(ball.position.z < -12 && ball.position.z > -14) checkpoint.set(0,1,-12);
  }
  const camTarget=new THREE.Vector3(ball.position.x*.45,ball.position.y+2.8,ball.position.z+6.8);
  camera.position.lerp(camTarget,1-Math.pow(.001,dt));camera.lookAt(ball.position.x,ball.position.y+.2,ball.position.z-2.2);
}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.033);update(dt);renderer.render(scene,camera);}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));});
